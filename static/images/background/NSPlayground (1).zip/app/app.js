import Vue from 'nativescript-vue';
import HelloWorld from './components/HelloWorld';
new Vue({
    render: h => h(HelloWorld),

}).$start();