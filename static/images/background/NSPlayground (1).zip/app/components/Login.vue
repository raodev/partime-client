<template>
    <Label text="hello world!" />
</template>

<script>
export default {
    data() {
	    return {
	    };
    }
}
</script>

<style>
</style>